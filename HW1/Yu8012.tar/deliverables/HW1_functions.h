#ifndef HW1_HEADER
#define HW1_HEADER


void question_1();
void question_2();
void question_3();
void question_4();
void question_5();
void question_6();
void question_7();


#endif